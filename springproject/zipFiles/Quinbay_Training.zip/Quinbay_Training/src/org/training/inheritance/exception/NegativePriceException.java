package org.training.inheritance.exception;

public class NegativePriceException extends Exception{
    public NegativePriceException(String message) {
        super(message);
    }
}
