package org.training.inheritance.exception;

public class CostZeroDiscountException extends  Exception {
    public CostZeroDiscountException(String message) {
        super(message);
    }
}
