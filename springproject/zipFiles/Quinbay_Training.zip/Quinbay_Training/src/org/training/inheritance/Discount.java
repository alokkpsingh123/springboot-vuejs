package org.training.inheritance;

public interface Discount {

    float calculateDiscount(int discount);
}
