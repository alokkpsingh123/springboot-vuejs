package org.training.inheritance;

public class Electronics extends Product implements Discount{
    private String brand;

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public Electronics() {
    }

    public Electronics(String brand) {
        this.brand = brand;
    }

    public Electronics(String name, float price, String brand) {
        super(name, price);
        this.brand = brand;
    }

    @Override
    public float calculateDiscount(int discount) {

        float discountAmount = (this.getPrice() * (float) discount) / 100;
        float afterDiscount = this.getPrice() - discountAmount;

        return afterDiscount;
    }



}
