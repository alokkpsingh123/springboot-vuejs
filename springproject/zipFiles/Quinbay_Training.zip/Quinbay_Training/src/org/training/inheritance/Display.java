package org.training.inheritance;

import org.training.inheritance.exception.CostZeroDiscountException;
import org.training.inheritance.exception.NegativePriceException;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class Display {

    private static float calculatePrice(Product product) {
        float actualPrice = 0.0f;
        int discount = 20;

        try{
            if(product.getPrice() < 0){
                throw new NegativePriceException("Enter correct price of the product.");
            }

            if (discount > 0 && product.getPrice() == 0){
                throw new CostZeroDiscountException("Discount can not be applied on zero cost of product");
            }


            if(product instanceof Discount){
                actualPrice = ((Discount) product).calculateDiscount(discount);
            }else {
                actualPrice = product.getPrice();
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }



        return actualPrice;
    }

    public static void main(String[] args) {

        /*

        -------Reflection Example---------

         Field[] fields = Electronics.class.getDeclaredFields();
        Method[] methods = Electronics.class.getMethods();



        for (Field field : fields){
            System.out.println("field -> "+ field.getName());
        }

        Electronics eleObj = new Electronics("laptop", 140,"Apple");
        for (Method method : methods){
            System.out.println("method -> " + method.getName());

            if("calculateDiscount".equals(method.getName())){
                method.setAccessible(true);
                System.out.println(method.invoke(eleObj,20));
            }
        }

         */




            List<Product> listProduct = new ArrayList<Product>();

            listProduct.add(new Electronics("laptop", 140, "Apple"));
            listProduct.add(new Electronics("mobile", 120, "Apple"));
            listProduct.add(new Electronics("iron", 160, "bajaj"));
            listProduct.add(new Electronics("watch", 90, "oneplus"));
            listProduct.add(new Clothes("tshit", 111, 42));
            listProduct.add(new Clothes("pant", 142, 36));
            listProduct.add(new Clothes("bedsheet", 178, 40));
            listProduct.add(new Clothes("jeans", 140, 46));

            float sumOfAllProducts = 0.0f;

            for(Product product : listProduct){
                sumOfAllProducts += calculatePrice(product);
            }

            System.out.println("Sum of All Products : "+ sumOfAllProducts);

    }
}
