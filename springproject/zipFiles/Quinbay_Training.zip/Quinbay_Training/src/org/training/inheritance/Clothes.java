package org.training.inheritance;

public class Clothes  extends Product{
    private int size;

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public Clothes() {
    }

    public Clothes(int size) {
        this.size = size;
    }

    public Clothes(String name, float price, int size) {
        super(name, price);
        this.size = size;
    }



}
