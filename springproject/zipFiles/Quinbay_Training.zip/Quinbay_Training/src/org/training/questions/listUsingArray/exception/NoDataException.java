package org.training.questions.listUsingArray.exception;

public class NoDataException extends Exception {
    public NoDataException(String message) {
        super(message);
    }
}
