package org.training.questions.frequencyCalculate;

import java.util.HashMap;
import java.util.Map;

public class CalculateFrequency {

    public Map<Integer, Integer> calculateFrequency(int arr[]){
        Map<Integer, Integer> map = new HashMap<Integer, Integer>();

        if( arr == null){
            System.out.println("Input Correct Array");
        }else{
            for(int item: arr){

                if(map.containsKey(item)){
                    map.put(item, map.get(item) + 1);
                }else {
                    map.put(item, 1);
                }

            }
        }
        return  map;
    }

    public static void main(String[] args) {

        CalculateFrequency obj = new CalculateFrequency();

        int arr[] = new int[]{1,1,2,2,2,3,4,4};

        Map<Integer, Integer> result = new HashMap<>();
        result = obj.calculateFrequency(arr);

//        for (int key : result.keySet()){
//            System.out.println(key + " " + result.get(key));
//        }

        for(Map.Entry<Integer, Integer> entry : result.entrySet()){
            System.out.println(entry.getKey() + " " + entry.getValue());
        }

    }
}
