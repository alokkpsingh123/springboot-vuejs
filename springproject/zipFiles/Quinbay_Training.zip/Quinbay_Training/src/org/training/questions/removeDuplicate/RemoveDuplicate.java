package org.training.questions.removeDuplicate;

import java.util.HashSet;
import java.util.Set;

public class RemoveDuplicate {

    public Set<Integer> removeDuplicate(int arr[]){

        Set<Integer> set = new HashSet<Integer>();

        if(arr == null){
            System.out.println("Enter the Correct Array");
        }else{
            for (int item : arr){
                set.add(item);
            }
        }

        return set;
    }

    public static void main(String[] args) {

        RemoveDuplicate obj = new RemoveDuplicate();

        Set<Integer> result = new HashSet<Integer>();

        int arr[] = new int[]{1,1,2,2,2,3,4,4};

        result = obj.removeDuplicate(arr);

        for (int item: result){
            System.out.println(item);
        }
    }
}
