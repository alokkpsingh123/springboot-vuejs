package org.training.questions.listUsingArray.exception;

public class MaxSizeException extends Exception {
    public MaxSizeException(String message) {
        super(message);
    }
}
