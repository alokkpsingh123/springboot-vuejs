package org.training.questions.listUsingArray;

import org.training.questions.listUsingArray.exception.MaxSizeException;
import org.training.questions.listUsingArray.exception.NoDataException;

public class Display {
    public static void main(String[] args) {
        MyList myList = new MyList();

        try{
            for (int i = 1; i<=10; i++){
                myList.addValue(i);
            }

            myList.deleteByIndex(5);
            myList.deleteByValue(10);
            int valueAtIndex = myList.getValueAtIndex(2);
            System.out.println("value At index "+ 2 + " : " + valueAtIndex);
            System.out.println(myList + "\nsize: " + myList.getSize());

        }catch (MaxSizeException | NoDataException e){
            System.out.println(e.getMessage());
        }

    }
}
