package org.training.questions.listUsingArray;

import org.training.questions.listUsingArray.exception.MaxSizeException;
import org.training.questions.listUsingArray.exception.NoDataException;

import java.util.Arrays;

public class MyList {

    private int arr[] = new int[10];
    private int size = 0;

    public int getSize() {
        return size;
    }

    public void addValue(int value) throws MaxSizeException{

        if(size >= 10){
            throw new MaxSizeException("Cannot add more value, maximum size reached");
        }
        arr[size] = value;
        size++;
    }

    public void deleteByIndex(int index) throws NoDataException{
        if(index < 0 || index >= size){
            throw new NoDataException("Wrong index, no data available at the given index");
        }
        for(int i = index; i< size -1; i++){
            arr[i] = arr[i+1];
        }

        size--;
    }

    public void deleteByValue(int value) throws NoDataException{
        boolean isFound = false;

        for(int i = 0; i< size; i++){
            if(arr[i] == value){
                deleteByIndex(i);
                isFound = true;
                break;
            }
        }

        if(!isFound){
            throw new NoDataException("Value not found in the list");
        }
    }

    public int getValueAtIndex(int index) throws NoDataException{
        if(index < 0 || index >= size){
            throw  new NoDataException("Wrong index, no data available at the given index");
        }
        return arr[index];
    }

    @Override
    public String toString() {
        return "MyList{" +
                "arr=" + Arrays.toString(arr) +
                '}';
    }
}
