package org.training.factorypattern.factory;

import org.training.factorypattern.Dish.Dish;

public interface DishFactory {
    Dish createDish();
}
