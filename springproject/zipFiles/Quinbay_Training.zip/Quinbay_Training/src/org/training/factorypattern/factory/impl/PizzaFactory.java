package org.training.factorypattern.factory.impl;

import org.training.factorypattern.Dish.Dish;
import org.training.factorypattern.Dish.impl.PizzaImpl;
import org.training.factorypattern.factory.DishFactory;

public class PizzaFactory implements DishFactory {
    @Override
    public Dish createDish() {
        return new PizzaImpl();
    }
}
