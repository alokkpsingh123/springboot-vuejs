package org.training.factorypattern.Dish.impl;

import org.training.factorypattern.Dish.Dish;

public class SushiImpl implements Dish {
    @Override
    public void prepare() {
        System.out.println("Preparing sushi...");
    }

    @Override
    public void serve() {
        System.out.println("Serving sushi...");
    }
}
