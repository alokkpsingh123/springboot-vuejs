package org.training.factorypattern.Dish.impl;

import org.training.factorypattern.Dish.Dish;

public class PizzaImpl implements Dish {
    @Override
    public void prepare() {
        System.out.println("Preparing pizza...");
    }

    @Override
    public void serve() {
        System.out.println("Serving pizza...");
    }
}
