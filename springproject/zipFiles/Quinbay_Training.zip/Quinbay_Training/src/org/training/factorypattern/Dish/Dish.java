package org.training.factorypattern.Dish;

public interface Dish {
    void prepare();
    void serve();
}
