package org.training.factorypattern.factory.impl;

import org.training.factorypattern.Dish.Dish;
import org.training.factorypattern.Dish.impl.SushiImpl;
import org.training.factorypattern.factory.DishFactory;

public class SushiFactory implements DishFactory {
    @Override
    public Dish createDish() {
        return new SushiImpl();
    }
}
