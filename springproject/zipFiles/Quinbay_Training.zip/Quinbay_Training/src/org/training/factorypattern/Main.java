package org.training.factorypattern;

import org.training.factorypattern.Dish.Dish;
import org.training.factorypattern.factory.DishFactory;
import org.training.factorypattern.factory.impl.PizzaFactory;
import org.training.factorypattern.factory.impl.SushiFactory;

public class Main {
    public static void main(String[] args) {

        // Order a pizza using the PizzaFactory
        DishFactory pizzaFactory = new PizzaFactory();
        Dish pizza = pizzaFactory.createDish();
        pizza.prepare();
        pizza.serve();

        // Order sushi using the SushiFactory
        DishFactory sushiFactory = new SushiFactory();
        Dish sushi = sushiFactory.createDish();
        sushi.prepare();
        sushi.serve();
    }
}
