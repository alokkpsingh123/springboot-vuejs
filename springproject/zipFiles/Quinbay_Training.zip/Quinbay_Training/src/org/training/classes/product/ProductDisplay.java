package org.training.classes.product;

import org.training.classes.product.Product;

public class ProductDisplay {

    public static void main(String[] args) {
        Product obj = new Product();
        obj.setName("Apple");
        obj.setPrice(12000);
        System.out.println(obj.getName() + " "+ obj.getPrice());
    }
}
