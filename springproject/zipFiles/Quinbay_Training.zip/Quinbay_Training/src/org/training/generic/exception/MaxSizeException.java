package org.training.generic.exception;

public class MaxSizeException extends Exception {
    public MaxSizeException(String message) {
        super(message);
    }
}
