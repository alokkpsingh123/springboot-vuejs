package org.training.generic.exception;

public class NoDataException extends Exception {
    public NoDataException(String message) {
        super(message);
    }
}
