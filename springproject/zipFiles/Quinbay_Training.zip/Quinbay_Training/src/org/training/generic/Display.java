package org.training.generic;

import org.training.generic.exception.MaxSizeException;
import org.training.generic.exception.NoDataException;

public class Display {
    public static void main(String[] args) {
        MyListGeneric<String> myList = new MyListGeneric<>();

        try{
            for (int i = 1; i<=10; i++){
                myList.addValue("alok");
            }

            myList.deleteByIndex(5);
            myList.deleteByValue("alok");
            String valueAtIndex = myList.getValueAtIndex(2);
            System.out.println("value At index "+ 2 + " : " + valueAtIndex);
            System.out.println(myList + "\nsize: " + myList.getSize());

        }catch (MaxSizeException | NoDataException e){
            System.out.println(e.getMessage());
        }

    }
}
