package org.training.generic;

import org.training.generic.exception.MaxSizeException;
import org.training.generic.exception.NoDataException;

import java.util.Arrays;

public class MyListGeneric<T> {

    private static final int MAX_SIZE = 100;
    private int size = 0;

    private T[] arr = (T[]) new Object[MAX_SIZE];

    public int getSize() {
        return size;
    }

    public void addValue(T value) throws MaxSizeException {

        if(size >= 10){
            throw new MaxSizeException("Cannot add more value, maximum size reached");
        }
        arr[size] = value;
        size++;
    }

    public void deleteByIndex(int index) throws NoDataException {
        if(index < 0 || index >= size){
            throw new NoDataException("Wrong index, no data available at the given index");
        }
        for(int i = index; i< size -1; i++){
            arr[i] = arr[i+1];
        }

        size--;
    }

    public void deleteByValue(T value) throws NoDataException{
        boolean isFound = false;

        for(int i = 0; i< size; i++){
            if(arr[i] == value){
                deleteByIndex(i);
                isFound = true;
                break;
            }
        }

        if(!isFound){
            throw new NoDataException("Value not found in the list");
        }
    }

    public  T getValueAtIndex(int index) throws NoDataException{
        if(index < 0 || index >= size){
            throw  new NoDataException("Wrong index, no data available at the given index");
        }
        return arr[index];
    }

    @Override
    public String toString() {
        return "MyListGeneric{" +
                "arr=" + Arrays.toString(arr) +
                '}';
    }
}
