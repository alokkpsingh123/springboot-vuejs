package org.alok.smspostgres.service;

import org.alok.smspostgres.dto.CourseDTO;
import org.alok.smspostgres.entity.Course;
import org.alok.smspostgres.entity.Student;

public interface CourseService {


    CourseDTO registerCourse(Course course);

    void deRegisterCourse(String courseId);

}
