package org.alok.smspostgres.controller;


import org.alok.smspostgres.dto.InstructorDTO;
import org.alok.smspostgres.entity.Instructor;
import org.alok.smspostgres.service.InstructorService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/instructor")
public class InstructorController {

    @Autowired
    InstructorService instructorService;


    @PostMapping("/registerInstructor")
    ResponseEntity<InstructorDTO> registerInstructor(@RequestBody InstructorDTO instructorDTO){
        Instructor instructor = new Instructor();
        BeanUtils.copyProperties(instructorDTO, instructor);
        return ResponseEntity.ok(instructorService.registerInstructor(instructor));
    }

    @DeleteMapping("/deRegisterInstructor/{insId}")
    ResponseEntity<Map<String,Boolean>> deRegisterInstructor(@PathVariable String insId){
        instructorService.deRegisterInstructor(insId);
        Map<String, Boolean> response = new HashMap<>();
        response.put("de-registered",Boolean.TRUE);
        return ResponseEntity.ok(response);
    }

    @PutMapping("/updateInstructorDetails")
    ResponseEntity<InstructorDTO> updateInstructorDetails(@RequestBody InstructorDTO instructorDTO){
        Instructor instructor = new Instructor();
        BeanUtils.copyProperties(instructorDTO, instructor);
        instructor.setDateOfBirth(new Date(instructorDTO.getDateOfBirth()));
        return  ResponseEntity.ok(instructorService.updateInstructorDetails(instructor));

    }

    @PostMapping("/enrollForCourseInstructor")
    ResponseEntity<Map<String,Boolean>> enrollForCourse(@RequestParam("insId") String instructorId, @RequestParam("corId") String courseId){
        Map<String, Boolean> response = new HashMap<>();
        response.put("de-registered",Boolean.TRUE);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/withdrawCourseInstructor")
    ResponseEntity<Map<String,Boolean>> withdrawCourse(@RequestParam("indId") String instructorId, @RequestParam("corId") String courseId){
        Map<String, Boolean> response = new HashMap<>();
        response.put("de-registered",Boolean.TRUE);
        return ResponseEntity.ok(response);
    }

}
