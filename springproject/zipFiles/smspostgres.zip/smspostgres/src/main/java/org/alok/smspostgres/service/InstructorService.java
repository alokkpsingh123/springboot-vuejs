package org.alok.smspostgres.service;

import org.alok.smspostgres.dto.InstructorDTO;
import org.alok.smspostgres.entity.Instructor;

public interface InstructorService {

    InstructorDTO registerInstructor(Instructor instructor);

    void deRegisterInstructor(String instructorId);

    InstructorDTO updateInstructorDetails( Instructor instructor);

    void enrollForCourse(String instructorId, String courseId);

    void withdrawCourse(String instructorId, String courseId);

}
