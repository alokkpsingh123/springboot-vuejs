package org.alok.smspostgres.controller;


import org.alok.smspostgres.dto.CourseProgressDTO;
import org.alok.smspostgres.dto.StudentDTO;
import org.alok.smspostgres.dto.StudentResponseDTO;
import org.alok.smspostgres.entity.Student;
import org.alok.smspostgres.service.StudentService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/student")
public class StudentController {

    @Autowired
    StudentService studentService;

    @GetMapping("/getStudentDetails/{stdId}")
    public ResponseEntity<StudentResponseDTO> getStudentDetail(@PathVariable String stdId){
        return ResponseEntity.ok(studentService.getStudentDetail(stdId));
    }

    @GetMapping("/getCourseProgress/{stdId}")
    public ResponseEntity<List<CourseProgressDTO>> getCourseProgress(@PathVariable String stdId){
        List<CourseProgressDTO> courseProgressDTOList = studentService.getCourseProgress(stdId);
        return ResponseEntity.ok(courseProgressDTOList);
    }

    @PostMapping("/registerStudent")
    ResponseEntity<StudentDTO> registerStudent(@RequestBody StudentDTO studentDTO){
        Student student = new Student();
        BeanUtils.copyProperties(studentDTO, student);
        student.setDateOfBirth(new Date(studentDTO.getDob()));
        return ResponseEntity.ok(studentService.registerStudent(student));
    }

    @DeleteMapping("/deRegisterStudent/{stdId}")
    ResponseEntity<Map<String,Boolean>> deRegisterStudent(@PathVariable String stdId){
        studentService.deRegisterStudent(stdId);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted",Boolean.TRUE);
        return ResponseEntity.ok(response);
    }

    @PutMapping("/updateStudentDetails")
    ResponseEntity<StudentDTO> updateStudentDetails(@RequestBody StudentDTO studentDTO){
        Student student = new Student();
        BeanUtils.copyProperties(studentDTO, student);
        return ResponseEntity.ok(studentService.updateStudentDetails(student));
    }

    @PostMapping("/enrollForCourse")
    ResponseEntity<Map<String,Boolean>> enrollForCourse(@RequestParam("stdId") String studentId, @RequestParam("corId") String courseId){
        studentService.enrollForCourse(studentId, courseId);
        Map<String, Boolean> response = new HashMap<>();
        response.put("enrolled",Boolean.TRUE);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/withdrawCourse")
    ResponseEntity<Map<String,Boolean>> withdrawCourse(@RequestParam("stdId") String studentId, @RequestParam("corId") String courseId){
        studentService.withdrawCourse(studentId, courseId);
        Map<String, Boolean> response = new HashMap<>();
        response.put("enrolled",Boolean.TRUE);
        return ResponseEntity.ok(response);
    }

}
