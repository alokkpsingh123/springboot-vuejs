package org.alok.smspostgres;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmspostgresApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmspostgresApplication.class, args);
	}

}
