package org.alok.smspostgres.dto;


import lombok.Data;

@Data
public class CourseProgressDTO {
    private String courseName;
    private String courseProgress;
}
