package org.alok.smspostgres.controller;

import org.alok.smspostgres.dto.CourseDTO;
import org.alok.smspostgres.entity.Course;
import org.alok.smspostgres.service.CourseService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/course")
public class CourseController {

    @Autowired
    CourseService courseService;

    @PostMapping("/registerCourse")
    ResponseEntity<CourseDTO> registerCourse(@RequestBody CourseDTO courseDTO){
        Course course = new Course();
        BeanUtils.copyProperties(courseDTO, course);
        return ResponseEntity.ok(courseService.registerCourse(course));
    }

    @DeleteMapping("/deRegisterCourse/{corId}")
    ResponseEntity<Map<String,Boolean>> deRegisterCourse(@PathVariable String corId){
        courseService.deRegisterCourse(corId);
        Map<String, Boolean> response = new HashMap<>();
        response.put("de-registered",Boolean.TRUE);
        return ResponseEntity.ok(response);
    }
}
