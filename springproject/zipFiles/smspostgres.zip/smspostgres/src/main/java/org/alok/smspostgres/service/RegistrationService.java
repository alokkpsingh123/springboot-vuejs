package org.alok.smspostgres.service;

public interface RegistrationService {

    void registerStudentForCourse(String studentId, String courseId);

    void withdrawStudentFromCourse(String studentId, String courseId);

    void registerInstructorForCourse(String instructorId, String courseId);

    void withdrawInstructorFromCourse(String instructorId, String courseId);
}
