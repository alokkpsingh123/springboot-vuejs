package org.alok.smspostgres.service.Impl;

import lombok.extern.slf4j.Slf4j;
import org.alok.smspostgres.dto.InstructorDTO;
import org.alok.smspostgres.entity.Instructor;
import org.alok.smspostgres.entity.Student;
import org.alok.smspostgres.repository.InstructorRepository;
import org.alok.smspostgres.service.InstructorService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Slf4j
public class InstructorServiceImpl implements InstructorService {

    @Autowired
    InstructorRepository instructorRepository;
    
    @Autowired
    RegistrationService registrationService;

    @Override
    public InstructorDTO registerInstructor(Instructor instructor) {

        InstructorDTO instructorDTO = new InstructorDTO();
        instructor = instructorRepository.save(instructor);
        BeanUtils.copyProperties(instructor, instructorDTO);
        return instructorDTO;
    }

    @Override
    public void deRegisterInstructor(String instructorId) {
        instructorRepository.deleteById(instructorId);
    }

    @Override
    public InstructorDTO updateInstructorDetails( Instructor instructor) {
        Optional<Instructor> instructorOptional = instructorRepository.findById(instructor.getInstructorId());
        if(instructorOptional.isPresent()){
            InstructorDTO instructorDTO = new InstructorDTO();
            instructor = instructorRepository.save(instructor);
            BeanUtils.copyProperties(instructor,instructorDTO);
            return instructorDTO;
        }else {
            log.error("Student does not exist");
            return null;
        }
    }

    @Override
    public void enrollForCourse(String instructorId, String courseId) {
        registrationService.registerInstructorForCourse(instructorId, courseId);
    }

    @Override
    public void withdrawCourse(String instructorId, String courseId) {
        registrationService.withdrawInstructorFromCourse(instructorId, courseId);

    }


}
