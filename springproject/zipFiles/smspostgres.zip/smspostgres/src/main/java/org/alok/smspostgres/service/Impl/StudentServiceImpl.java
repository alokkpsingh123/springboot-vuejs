package org.alok.smspostgres.service.Impl;


import lombok.extern.slf4j.Slf4j;
import org.alok.smspostgres.dto.CourseProgressDTO;
import org.alok.smspostgres.dto.StudentDTO;
import org.alok.smspostgres.dto.StudentResponseDTO;
import org.alok.smspostgres.entity.Course;
import org.alok.smspostgres.entity.Student;
import org.alok.smspostgres.repository.StudentRepository;
import org.alok.smspostgres.service.StudentService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class StudentServiceImpl implements StudentService {

    @Autowired
    StudentRepository studentRepository;

    @Autowired
    RegistrationService registrationService;


    @Override
    public StudentDTO registerStudent(Student student) {
        StudentDTO studentDTO = new StudentDTO();
        student = studentRepository.save(student);
        BeanUtils.copyProperties(student, studentDTO);
        return studentDTO;
    }

    @Override
    public void deRegisterStudent(String studentId) {
        studentRepository.deleteById(studentId);
    }

    @Override
    public StudentDTO updateStudentDetails(Student student) {

        Optional<Student> studentOptional = studentRepository.findById(student.getStudentId());
        if(studentOptional.isPresent()){
            StudentDTO studentDTO = new StudentDTO();
            student = studentRepository.save(student);
            BeanUtils.copyProperties(student,studentDTO);
            return studentDTO;
        }else {
            log.error("Student does not exist");
            return null;
        }

    }


    @Override
    public List<CourseProgressDTO> getCourseProgress(String studentId) {

        Optional<Student> studentOptional = studentRepository.findById(studentId);

        if (studentOptional.isPresent()) {
            Student student = studentOptional.get();
            List<Course> courses = student.getCourses();

            List<CourseProgressDTO> courseProgressList = new ArrayList<>();
            for (Course course : courses) {
                CourseProgressDTO courseProgress = new CourseProgressDTO();
                courseProgress.setCourseName(course.getCourseName());
                courseProgress.setCourseProgress(course.getCourseProgress());
                courseProgressList.add(courseProgress);
            }

            return courseProgressList;
        }else {
            log.error("Student does not exist");
            return null;
        }
    }

    @Override
    public StudentResponseDTO getStudentDetail(String studentId) {
        Optional<Student> studentOptional = studentRepository.findById(studentId);

        if (studentOptional.isPresent()) {
            Student student = studentOptional.get();

            StudentResponseDTO studentResponseDTO = new StudentResponseDTO();
            studentResponseDTO.setStudentId(student.getStudentId());
            studentResponseDTO.setStudentName(student.getStudentName());
            studentResponseDTO.setDateOfBirth(student.getDateOfBirth());
            studentResponseDTO.setCourses(student.getCourses());

            return studentResponseDTO;
        } else {
            log.error("Student does not exist");
            return null;
        }
    }

    @Override
    public void enrollForCourse(String studentId, String courseId) {
        registrationService.registerStudentForCourse(studentId, courseId);
    }

    @Override
    public void withdrawCourse(String studentId, String courseId) {
        registrationService.withdrawStudentFromCourse(studentId, courseId);
    }
}
