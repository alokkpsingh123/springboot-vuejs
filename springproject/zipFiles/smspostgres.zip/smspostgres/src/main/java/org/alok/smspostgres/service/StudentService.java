package org.alok.smspostgres.service;

import org.alok.smspostgres.dto.CourseProgressDTO;
import org.alok.smspostgres.dto.StudentDTO;
import org.alok.smspostgres.dto.StudentResponseDTO;
import org.alok.smspostgres.entity.Student;

import java.util.List;

public interface StudentService {

    StudentDTO registerStudent(Student student);

    void deRegisterStudent(String studentId);

    StudentDTO updateStudentDetails(Student student);

    List<CourseProgressDTO> getCourseProgress(String studentId);

    StudentResponseDTO getStudentDetail(String studentId);

    void enrollForCourse(String studentId, String courseId);

    void withdrawCourse(String studentId, String courseId);

}
