package main.java.handler.impl;

import com.opencsv.CSVWriter;
import main.java.entity.Employee;
import main.java.entity.MyCollection;
import main.java.handler.MyFileHandler;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CSVFileHandler implements MyFileHandler {

    private MyCollection myCollection;

    public  CSVFileHandler(){
        myCollection = MyCollection.getInstance();
    }


    @Override
    public void read() {

        try{

            CSVParser parser;
            FileReader data = new FileReader("/Users/aloksingh/IdeaProjects/FileHandlerProject/src/main/resource/employee.csv");
            parser = CSVParser.parse(data, CSVFormat.DEFAULT);

            for (CSVRecord csvRecord : parser) {


                Employee employee = new Employee();
                employee.setFirstName(csvRecord.get(0));
                employee.setLastName(csvRecord.get(1));
                employee.setDateOfBirth(new SimpleDateFormat("MM/dd/yy").parse(csvRecord.get(2)));
                employee.setExperience(Double.parseDouble(csvRecord.get(3)));

                myCollection.add(employee);
            }
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }

    }

    @Override
    public void write() {

        String csvFilename = "/Users/aloksingh/IdeaProjects/FileHandlerProject/src/main/resource/employeedata.csv";
        try{

            CSVWriter writer = new CSVWriter(new FileWriter(csvFilename));

            for(int i =0; i< 100; i++){
                Employee employee = MyCollection.getInstance().get();

                String[] csvData = {
                        employee.getFirstName(),
                        employee.getLastName(),
                        handleDateFormater(employee.getDateOfBirth()),
                        Double.toString(employee.getExperience())
                };
                writer.writeNext(csvData);

            }
            writer.close();

        }catch (Exception e){
            System.out.println(e.getMessage());
        }


    }

    private String handleDateFormater(Date date){

        Date dateWithoutTime = null;
        try{
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
            dateWithoutTime = sdf.parse(sdf.format(date));

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
        return dateWithoutTime.toString();
    }
}
