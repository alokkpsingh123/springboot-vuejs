package main.java.handler.impl;

import main.java.entity.Employee;
import main.java.entity.MyCollection;
import main.java.handler.MyFileHandler;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class XMLFileHandler implements MyFileHandler {

    private MyCollection myCollection;

    public  XMLFileHandler(){
        myCollection = MyCollection.getInstance();
    }

    @Override
    public void read() {


        try {
            File file = new File("/Users/aloksingh/IdeaProjects/FileHandlerProject/src/main/resource/employee.xml");
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.parse(file);

            doc.getDocumentElement().normalize();

            NodeList nodeList = doc.getElementsByTagName("employee");
            System.out.println(nodeList);
            for( int itr = 0 ; itr < nodeList.getLength() ; itr++){
                Node node = nodeList.item(itr);
                Employee employee = new Employee();

                if(node.getNodeType() == Node.ELEMENT_NODE){
                    Element el = (Element) node;

                    employee.setFirstName(el.getElementsByTagName("firstName").item(0).getTextContent());
                    employee.setLastName(el.getElementsByTagName("lastName").item(0).getTextContent());
                    employee.setDateOfBirth(new SimpleDateFormat("MM/dd/yy").parse(el.getElementsByTagName("dateOfBirth").item(0).getTextContent()));
                    employee.setExperience(Double.parseDouble(el.getElementsByTagName("experience").item(0).getTextContent()));

                    myCollection.add(employee);

                }
            }
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void write() {

        String xmlFilename = "/Users/aloksingh/IdeaProjects/FileHandlerProject/src/main/resource/employeedata.xml";

        try(BufferedWriter writer = new BufferedWriter(new FileWriter(new File(xmlFilename)))){
            writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
            writer.write("<employees>\n");
            for(int i =0; i< 100; i++){
                Employee employee = MyCollection.getInstance().get();
                if (employee != null) {
                    String xmlData = String.format("    <employee>\n" +
                                    "        <firstName>%s</firstName>\n" +
                                    "        <lastName>%s</lastName>\n" +
                                    "        <dateOfBirth>%s</dateOfBirth>\n" +
                                    "        <experience>%s</experience>\n" +
                                    "    </employee>\n",
                            employee.getFirstName(), employee.getLastName(),
                            handleDateFormater(employee.getDateOfBirth()) , employee.getExperience());

                    writer.append(xmlData);
                }

            }

        }catch (Exception e){
            System.out.println(e.getMessage());
        }

    }
    private String handleDateFormater(Date date){

        Date dateWithoutTime = null;
        try{
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
            dateWithoutTime = sdf.parse(sdf.format(date));

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
        return dateWithoutTime.toString();
    }
}
