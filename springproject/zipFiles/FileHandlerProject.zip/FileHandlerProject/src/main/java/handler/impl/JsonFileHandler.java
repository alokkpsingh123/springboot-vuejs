package main.java.handler.impl;

import main.java.entity.Employee;
import main.java.entity.MyCollection;
import main.java.handler.MyFileHandler;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.FileReader;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class JsonFileHandler implements MyFileHandler {

    private MyCollection myCollection;

    public  JsonFileHandler(){
        myCollection = MyCollection.getInstance();
    }

    @Override
    public void read() {

        JSONParser parserJson = new JSONParser();
        try {
            JSONArray a = (JSONArray) parserJson.parse(new FileReader("/Users/aloksingh/IdeaProjects/FileHandlerProject/src/main/resource/employee.json"));

            for (Object o : a) {
                JSONObject person = (JSONObject) o;

                Employee employee = new Employee();
                employee.setFirstName((String) person.get("firstName"));
                employee.setLastName((String) person.get("lastName"));
                employee.setExperience(Double.parseDouble(person.get("experience") + ""));
                employee.setDateOfBirth(new SimpleDateFormat("MM/dd/yy").parse(person.get("dateOfBirth") + ""));

                myCollection.add(employee);
            }

        } catch(Exception e) {
            System.out.println(e.getMessage());
        }

    }

    @Override
    public void write() {

        String jsonFilename = "/Users/aloksingh/IdeaProjects/FileHandlerProject/src/main/resource/employeedata.json";

        try{
            FileWriter file = new FileWriter(jsonFilename);
            JSONArray jsonArray = new JSONArray();

            for(int i =0; i< 100; i++){
                Employee employee = MyCollection.getInstance().get();
                if (employee != null) {
                    JSONObject employeeJson = createEmployeeJson(employee);

                    jsonArray.add(employeeJson);
                }
            }
            file.append(jsonArray.toJSONString());
            file.close();

        }catch (Exception e){
            System.out.println(e.getMessage());
        }

    }

    private JSONObject createEmployeeJson(Employee employee) {
        JSONObject employeeJson = new JSONObject();
        employeeJson.put("firstName", employee.getFirstName());
        employeeJson.put("lastName", employee.getLastName());
        employeeJson.put("dateOfBirth", handleDateFormater(employee.getDateOfBirth()));
        employeeJson.put("experience", employee.getExperience());
        return employeeJson;
    }

    private String handleDateFormater(Date date){

        Date dateWithoutTime = null;
        try{
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
            dateWithoutTime = sdf.parse(sdf.format(date));

        }catch (Exception e){
            System.out.println(e.getMessage());
        }
        return dateWithoutTime.toString();
    }
}
