package main.java.handler;

import main.java.entity.Employee;
import main.java.entity.MyCollection;

public interface MyFileHandler {

    public void read();
    public void write();
}
