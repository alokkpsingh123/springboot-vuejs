package main.java.entity;

public class MyCollection {

    private static final int MAX_SIZE = 300;
    private Employee [] employees = new Employee[MAX_SIZE];
    private int writeCounter = 0;
    private int readCounter = 0;

    /**
     * Making MyCollection Singleton
     */
    private static MyCollection instance;
    private MyCollection(){}

    public static MyCollection getInstance(){
        if(null == instance){
            synchronized (MyCollection.class){
                if (null == instance){
                    instance = new MyCollection();
                }
            }
        }
        return instance;
    }

    public int getWriteCounter() {
        return writeCounter;
    }

    public void setWriteCounter(int writeCounter) {
        this.writeCounter = writeCounter;
    }

    public int getReadCounter() {
        return readCounter;
    }

    public void setReadCounter(int readCounter) {
        this.readCounter = readCounter;
    }

    public  synchronized void add(Employee employee) throws Exception{
        if(employee == null){
            throw new Exception("Null value in the employee");
        }

        if(writeCounter >= MAX_SIZE){
           throw new Exception("Max sized reached");
        }

        employees[writeCounter++] = employee;

    }

    public synchronized Employee get() throws Exception{
        if(readCounter > writeCounter){
            throw new Exception("Data not available");
        }

        return employees[readCounter++];
    }
}
