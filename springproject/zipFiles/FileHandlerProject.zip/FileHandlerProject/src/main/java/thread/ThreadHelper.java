package main.java.thread;

import main.java.entity.MyCollection;
import main.java.handler.MyFileHandler;

public class ThreadHelper implements Runnable {

    MyFileHandler handler;
    boolean isRead;

    public ThreadHelper(MyFileHandler handler, boolean isRead) {
        this.handler = handler;
        this.isRead = isRead;
    }

    @Override
    public void run() {

        System.out.println("Current Thread: " + Thread.currentThread().getName());

        try{
            if(isRead){
                handler.read();
            }else {
                handler.write();
            }

        }catch (Exception e){
            System.out.println(e.getMessage());
        }

    }
}
