package main.java.controller;

import main.java.entity.MyCollection;
import main.java.handler.impl.CSVFileHandler;
import main.java.handler.impl.JsonFileHandler;
import main.java.handler.impl.XMLFileHandler;
import main.java.thread.ThreadHelper;

public class MyController {

    public static void main(String[] args) {

        try{

            Thread xmlReadThread = new Thread(new ThreadHelper(new XMLFileHandler(), Boolean.TRUE), "xmlReadThread");
            Thread jsonReadThread = new Thread(new ThreadHelper(new JsonFileHandler(), Boolean.TRUE),"jsonReadThread");
            Thread csvReadThread = new Thread(new ThreadHelper(new CSVFileHandler(), Boolean.TRUE),"csvReadThread");

            xmlReadThread.start();
            jsonReadThread.start();
            csvReadThread.start();

            xmlReadThread.join();
            jsonReadThread.join();
            csvReadThread.join();

            System.out.println("Write Counter: " +  MyCollection.getInstance().getWriteCounter());



            Thread xmlWriteThread = new Thread(new ThreadHelper(new XMLFileHandler(), Boolean.FALSE),"xmlWriteThread");
            Thread jsonWriteThread = new Thread(new ThreadHelper(new JsonFileHandler(), Boolean.FALSE),"jsonWriteThread");
            Thread csvWriteThread = new Thread(new ThreadHelper(new CSVFileHandler(), Boolean.FALSE),"csvWriteThread");

            xmlWriteThread.start();
            jsonWriteThread.start();
            csvWriteThread.start();

            xmlWriteThread.join();
            jsonWriteThread.join();
            csvWriteThread.join();

            System.out.println("Read Counter: " +  MyCollection.getInstance().getReadCounter());



        }catch (Exception e){
            System.out.println(e.getMessage());
        }




    }
}
