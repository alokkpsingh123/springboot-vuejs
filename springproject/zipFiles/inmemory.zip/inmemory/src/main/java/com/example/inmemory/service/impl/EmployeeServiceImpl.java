package com.example.inmemory.service.impl;

import com.example.inmemory.dto.EmployeeDto;
import com.example.inmemory.dto.EmployeeResponseDto;
import com.example.inmemory.entity.Employee;
import com.example.inmemory.repository.EmployeeRepository;
import com.example.inmemory.service.EmployeeService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.UUID;


@Service
public class EmployeeServiceImpl  implements EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public boolean addEmployee(EmployeeDto employeeDto) {

        Employee employee = new Employee();
        BeanUtils.copyProperties(employeeDto, employee);
        employee.setDob(new Date(employeeDto.getDateOfBirth()));
        employee.setDoj(new Date(employeeDto.getDateOfJoining()));
        employee.setEmployeeId(UUID.randomUUID().toString());
        Employee saveEmployee = employeeRepository.addEmployee(employee);

        return Objects.nonNull(saveEmployee);
    }

    @Override
    public List<Employee> getAll() {
        List<Employee> employeeList = employeeRepository.getAllEmployee();
        return employeeList;
    }

    @Override
    public boolean clearAll() {
        boolean result = employeeRepository.deleteAllEmployee();
        return result;
    }

    @Override
    public Employee get(String employeeId) {

        Employee employee = employeeRepository.getEmployeeById(employeeId);
        return employee;
    }

    @Override
    public boolean deleteById(String employeeId) {
        boolean result = employeeRepository.deleteEmployeeById(employeeId);
        return result;
    }

    @Override
    public boolean isEmployeeExist(String employeeId) {
        boolean result = employeeRepository.existsByEmployeeId(employeeId);
        return result;
    }


}
