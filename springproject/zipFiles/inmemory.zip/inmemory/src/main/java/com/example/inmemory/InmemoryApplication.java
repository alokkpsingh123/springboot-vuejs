package com.example.inmemory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InmemoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(InmemoryApplication.class, args);
	}

}
