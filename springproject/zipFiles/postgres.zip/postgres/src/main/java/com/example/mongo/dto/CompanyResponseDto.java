package com.example.mongo.dto;

import lombok.Data;

@Data
public class CompanyResponseDto {

    private String companyId;
    private String companyName;
}
