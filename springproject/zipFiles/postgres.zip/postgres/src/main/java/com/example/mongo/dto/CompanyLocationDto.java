package com.example.mongo.dto;

import lombok.Data;

@Data
public class CompanyLocationDto {
    private String locationId;
    private String city;
}
