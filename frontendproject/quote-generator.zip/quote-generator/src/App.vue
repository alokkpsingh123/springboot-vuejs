<template>
  <div class="container">
    <div class="container-show-text">{{ randomQuotes.quotes }}</div>
    <button @click="getNextQuote" class="btn-next">Next Quote</button>
  </div>
</template>

<script src="./js/app.js">

</script>

<style>
body {
  background-color: grey;
}

#app {
  margin: 200px auto;
  background-color: white;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 40%;
  border-radius: 2%;
}

.container {
  padding: 30px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.container-show-text {
  padding: 20px;
  font-size: 20px;
}

.btn-next {
  height: 50px;
  width: 100px;
}
</style>
