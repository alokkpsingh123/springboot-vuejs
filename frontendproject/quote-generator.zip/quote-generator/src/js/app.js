import { defineComponent, ref } from "vue";

export default defineComponent({
    setup(){

        const data = [ 
            { quotes : "Genius is one percent inspiration and ninety-nine percent perspiration."},
            { quotes : "Go ahead, make my day."},
            { quotes : "He travels the fastest who travels alone."},
            { quotes : "Hell has no fury like a woman scorned."},
            { quotes : "Ask, and it shall be given you; seek, and you shall find."},
            { quotes : "Eighty percent of success is showing up."}
        ]

        /**
         * Doubt: Not able to create with reactive
         */
        const randomQuotes = ref({
            quotes : "Elementary, my dear Watson."
        })
        const getNextQuote = () => {
            let random = Math.floor(Math.random() * data.length)
            console.log(data[random])
            randomQuotes.value = data[random]
            console.log(randomQuotes.value)
        }

        return {
            getNextQuote,
            randomQuotes
        }

    }
})