<template>
    <div>
        <p>Thi is a Deals section</p>
    </div>
</template>
<script>
</script>
<style>
</style>